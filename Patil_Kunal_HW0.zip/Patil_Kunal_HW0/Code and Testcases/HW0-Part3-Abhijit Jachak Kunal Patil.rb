# Pair Programming ----- HW0 - Part 1 --- Neelabh Agrawal, Chirag Gosalia
# Pair Programming ----- HW0 - Part 2 --- Vaibhav Khandelwal, Jesu Darison, Ashok Teja, Vishnu Ravindra, Mitra Singham
# Pair Programming ----- HW0 - Part 3 --- Kunal Patil , Abhijit Jachak
# Test cases 

#--- 1. Check if price_as_string is returned successfully for normal scenario
#--- 2. Check if Argument Error is raised if price is negative
#--- 3. Check if price_as_string is returned successfully if price mentioned in more than 2 decimal points
#--- 4. Check if Argument Error is raised if isbn is empty string


class BookInStock
def initialize(isbn, price)


raise ArgumentError if isbn == nil || isbn.length == 0
raise ArgumentError if price <= 0


@isbn  = isbn
@price = price

end

attr_accessor :isbn

def price
@price
end

def price=(price)
@price = price
end

def price_as_string
"$%0.2f" % @price
end

end

#--- Check if price_as_string is returned successfully for normal scenario
#book1 = BookInStock.new("test isbn", 50)
#puts book.price_as_string 

#--- Check if Argument Error is raised if price is zero
#book2 = BookInStock.new("test isbn_1", 0.00)
#puts book.price_as_string 

#--- Check if Argument Error is raised if price is negative
#book2 = BookInStock.new("test isbn_1", -5)
#puts book.price_as_string 

#--- Check if price_as_string is returned successfully if price mentioned in more than 2 decimal points
#book3 = BookInStock.new("test isbn_2", 75.4612542)
#puts book.price_as_string 

#--- Check if Argument Error is raised if isbn is empty string
#book2 = BookInStock.new("", 20.00)
#puts book.price_as_string 


#Youtube Link

#Part 3)  https://www.youtube.com/watch?feature=player_embedded&v=UH_uggQqUOE


