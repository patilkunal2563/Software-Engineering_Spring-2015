
def sum(arr)
    count = 0
    arr.each do |x|
        count += x
    end
    return count
end


#Test cases for sum(array)
#Check for empty array
puts sum([]) == 0
#Check for array with only 1 value
puts sum([7]) == 7
#Check for array with multiple integer values
puts sum([2,5,3]) == 10
#Check for negative integers
puts sum([1,-5,0,-7,7]) == -4

def max_2_sum(arr)
    if arr.count == 0
            return 0
    elsif arr.count == 1
        return arr[0]
    else
        sorted = arr.sort.reverse
        return sorted[0] + sorted[1]
    end
end 


#max_2_sum(array) Test Case :
#Check for empty array
puts max_2_sum([]) == 0
#Check for array with only 1 value
puts max_2_sum([2]) == 2
#Check for array with non integer values
puts max_2_sum([2,6,1,9,2]) == 15
#Check for negative integers
puts max_2_sum([-3,-4,-7]) == -7
#Check for array with same values
puts max_2_sum([2,5,5]) == 10       
    

def sum_to_n?(arr, total)
    if arr.count == 0 || arr.count == 1
        return false
    end
    
    arr.each_with_index do |x, xi|
        arr.each_with_index do |y, yi|
            if x + y == total && xi != yi
                return true
            end
        end
    end
    return false
end
 

#sum_teturn arr[0]
#Check for empty array
puts sum_to_n?([], 0) == false
#Check for array with only 1 value
puts sum_to_n?([3], 3) == false
#Check for array with two distinct integer sum to n
puts sum_to_n?([3,6,2,4], 7) == true
#Check for array with 2 pairs of two distinct integer sum to n
puts sum_to_n?([3,-6,-2,-4], -3) == true
#Check for array where any two distinct integer do not sum to n
puts sum_to_n?([3,6,2,4], 11) == false
