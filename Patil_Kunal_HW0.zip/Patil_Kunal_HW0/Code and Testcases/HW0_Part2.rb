#Define a method hello(name) that takes a string representing a name and returns the string "Hello, " concatenated with the name. 
def hello name
    "Hello, " + name
end

#Testcase for Method hello.
#puts hello("Vaibhav") == "Hello, Vaibhav"
#puts hello("") == "Hello, "
#puts hello("434") == "Hello, 434"
#puts hello("@#@") == "Hello, @#@"


#Define a method starts_with_consonant?(s) that takes a string and returns true if it starts with a consonant and false otherwise. (For our #purposes, a consonant is any letter other than A, E, I, O, U.) NOTE: be sure it works for both upper and lower case and for nonletters!

def starts_with_consonant? (s)
  !!(s[0] =~ /[bcdfghjklmnprstvwxyz]+/i)
end

#Testcase for method starts_with_consonant
#puts starts_with_consonant? ("Apple")
#puts starts_with_consonant? ("apple")
#puts starts_with_consonant? ("Wpple")
#puts starts_with_consonant? ("wpple")
#puts starts_with_consonant? ("1pple")
#puts starts_with_consonant? ("@pple")
#puts starts_with_consonant? (" dad")
#puts starts_with_consonant? (" ")


#Define a method binary_multiple_of_4?(s) that takes a string and returns true if the string represents a binary number that is a multiple of #NOTE: be sure it returns false if the string is not a valid binary number! 

def binary_multiple_of_4?(s)
    (s =~ /^[01]+$/) == 0 && (s == '0' || (s =~ /00$/) != nil)
end

#puts binary_multiple_of_4? "100fdf"
#puts binary_multiple_of_4? "100"
#puts binary_multiple_of_4? "1000"
#puts binary_multiple_of_4? "001"
#puts binary_multiple_of_4? "fdf"
#puts binary_multiple_of_4? "fdf100"
#puts binary_multiple_of_4? " "
#puts binary_multiple_of_4? "@100"

