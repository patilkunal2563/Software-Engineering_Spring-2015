HW0 Part 3 is done by Abhijit Jachak and Kunal Patil for
Part 1 and 2 we have collaborated with two other groups, their
hangouts urls are mentioned in hangouts folder.

-
Kunal Patil
