class RockPaperScissors

  # Exceptions this class can raise:
  class NoSuchStrategyError < StandardError ; end

  def self.winner(player1, player2)

    if !!(player1[1] && player2[1] =~ /[^RPS]/)
      raise NoSuchStrategyError, "Strategy must be one of R,P,S"
    elsif player1[1] == player2[1]
      player1
    elsif player1[1] + player2[1] =~ /PR|RS|SP/
      player1
    elsif player2[1] + player1[1] =~ /PR|RS|SP/
      player2
    end

  end

  def self.tournament_winner(tournament)
    if tournament[0][1].class == String
      winner(tournament[0], tournament[1])
    else
      pl1 = tournament_winner(tournament[0])
      pl2 = tournament_winner(tournament[1])
      tournament_winner([pl1,pl2])
    end
  end

end