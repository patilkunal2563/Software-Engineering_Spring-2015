HW1 Part 4 is done by Abhijit Jachak and Kunal Patil for
Part 1, 2 and 3, we have collaborated with two other groups, their
hangouts urls are mentioned in hangouts folder.

-
Kunal Patil
